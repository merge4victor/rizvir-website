/*******************************************************
 Windows HID simplification

 Alan Ott
 Signal 11 Software

 8/22/2009

 Copyright 2009, All Rights Reserved.
 
 This contents of this file may be used by anyone
 for any reason without any conditions and may be
 used as a starting point for your own applications
 which use HIDAPI.
********************************************************/

#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/stat.h>
#include <hidapi/hidapi.h>

#include "jpegdecode.h"

// Headers needed for sleeping.
#ifdef _WIN32
#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <strsafe.h>
#include <dbt.h>
#pragma comment(lib, "user32.lib")
#else
	#include <unistd.h>
#endif

#define BUFFERSIZE 64

typedef unsigned char byte;

unsigned int BytesToLong(byte b0, byte b1, byte b2, byte b3)
{
	return (unsigned int)b0 | (unsigned int)b1 << 8 | (unsigned int)b2 << 16 | (unsigned int)b3 << 24;
}


#include "jpegdecode.h"
#include "pngdecode.h"

int main(int argc, char* argv[])
{
	int res;
	unsigned char buf[256];
	#define MAX_STR 255
	wchar_t wstr[MAX_STR];
	hid_device *handle;
	int i;
	unsigned char *decodedImage;
	unsigned char *finalImage;
	int finalImageSize;
	int rescaledImageSize;
	int inputWidth, outputWidth, inputHeight, outputHeight;

//#ifdef WIN32
//	UNREFERENCED_PARAMETER(argc);
//	UNREFERENCED_PARAMETER(argv);
//#endif

	struct hid_device_info *devs, *cur_dev;

	if (hid_init())
		return -1;

	// Set up the command buffer.
	memset(buf,0x00,sizeof(buf));

	// Open the device using the VID, PID,
	// and optionally the Serial number.
	////handle = hid_open(0x4d8, 0x3f, L"12345");
	handle = hid_open(0x1fc9, 0x100b, NULL); // Display
	if (!handle) {
		printf("unable to open device, you need to be root\n");
		hid_exit();
 		return 1;
	}

    printf("\n");
    if( argc != 2 )
    {
		buf[0] = 0x0;
		buf[1] = 0x4;
		hid_write(handle, buf, 2);  //Toggle Backlight

		goto exit_program_no_pause;
    }

  int out_width;
  int out_height;
  int out_components;

  char *p = strrchr(argv[1], '.');
  if (p)
  {
    if ((strcmp(p, ".jpeg") == 0) || (strcmp(p, ".jpg") == 0))
	{
		fprintf(stderr, "Loading .jpg file, please wait...\n");
		if (!decodeJpeg(argv[1], &decodedImage, &out_width, &out_height, &out_components))
		{
			fprintf(stderr, "Error decoding .jpg file\n");
			goto exit_program_with_pause;
		}
	}
	else if (strcmp(p, ".png") == 0)
	{
		fprintf(stderr, "Loading .png file, please wait...\n");
		if (!decodePng(argv[1], &decodedImage, &out_width, &out_height, &out_components))
		{
			fprintf(stderr, "Error decoding .png file\n");
			goto exit_program_with_pause;
		}
	}
	else
	{
	  fprintf(stderr, "Must be of file type .jpeg .jpg .png or .bin\n");
      goto exit_program_with_pause;
	}
  }
  else
  {
	fprintf(stderr, "Must be of file type .jpeg .jpg or .bin\n");
    goto exit_program_with_pause;
  }

	inputWidth = out_width;
	inputHeight = out_height;
	outputWidth = 240;
	outputHeight = 320;

        //
        // Get a new buuffer to interpolate into
	    rescaledImageSize = outputWidth * outputHeight * 3;
        unsigned char* rescaledImage = new unsigned char [rescaledImageSize];

        double scaleWidth =  (double)outputWidth / (double)inputWidth;
        double scaleHeight = (double)outputHeight / (double)inputHeight;

        for(int cy = 0; cy < outputHeight; cy++)
        {
            for(int cx = 0; cx < outputWidth; cx++)
            {
                int pixel = (cy * (outputWidth *3)) + (cx*3);
                int nearestMatch =  (((int)(cy / scaleHeight) * (inputWidth * out_components)) + ((int)(cx / scaleWidth) * out_components) );
                
                rescaledImage[pixel    ] =  decodedImage[nearestMatch    ];
                rescaledImage[pixel + 1] =  decodedImage[nearestMatch + 1];
                rescaledImage[pixel + 2] =  decodedImage[nearestMatch + 2];
            }
        }

	finalImage = new unsigned char [outputWidth * outputHeight * 2];

	finalImageSize = 0;
	for (i=0; i < rescaledImageSize; i+=3)
	{
		unsigned short B = (rescaledImage[i + 2] >> 3) & 0x001F;
		unsigned short G = ((rescaledImage[i + 1] >> 2) <<  5) & 0x07E0;
		unsigned short R = ((rescaledImage[i] >> 3) << 11) & 0xF800;
		unsigned short RGB = (unsigned short) (R | G | B);
		finalImage[finalImageSize++] = (unsigned char)((RGB >> 8) & 0x00FF);
		finalImage[finalImageSize++] = (unsigned char)(RGB & 0x00FF);
	}

	buf[0] = 0x0;
	buf[1] = 0x1;
	buf[2] = 0xde;
	buf[3] = 0xad;
	buf[4] = 0xbe;
	buf[5] = 0xef;

	hid_write(handle, buf, 6);  //Erase Flash

	buf[0] = 0x0;
	buf[1] = 0x2;
	buf[2] = 0x00;

	i=0;
	while(1)
	{
		memcpy(&buf[3],(const unsigned char *)(finalImage + i), BUFFERSIZE-3);
		buf[2] = BUFFERSIZE-3;
		hid_write(handle, buf, BUFFERSIZE);

		if ((i + BUFFERSIZE-3) > finalImageSize)
		{
			int remainder = finalImageSize - i;
			memcpy(&buf[3],(const unsigned char *)(finalImage + i), remainder);
			buf[2] = remainder;
			hid_write(handle, buf, remainder + 3);
			break;
		}
		else
			i += BUFFERSIZE-3;
	}

    buf[0] = 0x0;
    buf[1] = 0x3;
    hid_write(handle, buf, 2);  //Refesh Display

	fprintf(stderr, "Image successfully updated\n");

	free(decodedImage);
	free(finalImage);
	free(rescaledImage);

exit_program_with_pause:

#ifdef WIN32
	system("pause");
#endif

exit_program_no_pause:

  hid_close(handle);

  /* Free static HIDAPI objects. */
  hid_exit();

  return 0;
}
