#include "png.h"

bool decodePng(char *inFile, unsigned char **outputImage, int *outWidth, int *outHeight, int *outComponents);