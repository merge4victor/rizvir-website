#include "jpeglib.h"
#include "jerror.h"

bool decodeJpeg(char *inFile, unsigned char **outputImage, int *outWidth, int *outHeight, int *outComponents);